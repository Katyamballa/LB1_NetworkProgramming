## Результати завдання: Отримання курсу валют із сайту НБУ

### Запит до API
URL:  
https://bank.gov.ua/NBU_Exchange/exchange_site?start=20240916&end=20240923&valcode=usd&sort=exchangedate&order=desc&json

Параметри:
- start: 20240916
- end: 20240923
- valcode: usd
- sort: exchangedate
- order: desc
- json: true

### Результат
Відповідь API збережено у файлі exchange_rates.json.